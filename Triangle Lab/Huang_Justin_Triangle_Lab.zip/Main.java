class Main {
  public static void main(String[] args) {
    //setup test cases
    System.out.print(TriangleFive.createTriangle("y",5));
    System.out.println(TriangleTwo.createTriangle("a", 6));
    System.out.println(TriangleThree.createTriangle("a", 6));
    System.out.println(TriangleFour.createTriangle("a", 6));

  }
}